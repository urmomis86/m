# SLOW ROADS SOURCE CODE VER 1.01
### By RobertTBS
<br>
** THIS IS NOT THE OFFICIAL SOURCE AND IS OUTDATED! **
<hr>
This is the source code to Slow Roads. I looked through the code and developer console and downloaded the code and all dependancies.
<br>
Visit the full preview at roberttbs.github.io/slowroads
<br>
All credits go to Anslo, visit the original at slowroads.io
<br>
Clarified from Anslo, this is under a http://creativecommons.org/licenses/by-nc-nd/4.0/ license, which means you can copy the original but not change the program; but it is stated this will be changed soon. 
<br>
VER: 1.01
